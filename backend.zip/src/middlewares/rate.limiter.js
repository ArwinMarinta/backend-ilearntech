/* const setRateLimit = require("express-rate-limit");

const rateLimiter = setRateLimit({
  windowMs: 60 * 1000,
  max: 20,
  message: {status: 'error', message: "Terlalu banyak permintaan dalam 1 menit"},
  headers: true,
})

module.exports = rateLimiter */