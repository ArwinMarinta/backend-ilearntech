const notification = require('./notification.controller')

module.exports = {
    notification
}