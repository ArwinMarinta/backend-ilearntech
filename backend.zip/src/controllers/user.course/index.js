const userCourse = require('./user.course.controller'),
    userWishlist = require('./user.whislist.controller'),
    checkController = require('./check.controller')

module.exports = {
    userCourse,
    userWishlist,
    checkController
}