const courseAnalytics = require('./course.analytics.controller')
const userAnalytics = require('./user.analytics.controller')

module.exports = {
    userAnalytics,
    courseAnalytics
}