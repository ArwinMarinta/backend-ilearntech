const courseDiscussion = require('./course.discussion.controller')
const discussion = require('./discussion.controller')
const commentarDiscussion = require('./commentar.discussion.controller')

module.exports = {
    courseDiscussion,
    discussion,
    commentarDiscussion
}