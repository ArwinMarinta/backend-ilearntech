const order = require('./order.controller')

module.exports = {
    order
}