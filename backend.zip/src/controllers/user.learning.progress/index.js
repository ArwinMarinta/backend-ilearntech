const userLearningProgress = require('./user.learning.progress.controller')

module.exports = {
    userLearningProgress
}
