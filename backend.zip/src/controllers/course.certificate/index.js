const certificate = require('./certificate.controller')

module.exports = {
    certificate
}